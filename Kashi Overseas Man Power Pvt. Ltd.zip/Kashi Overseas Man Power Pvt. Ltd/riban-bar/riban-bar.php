<div class="header">

<!-- Ribban Bar -->
<div class="ribban-bar">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-12">
            <span>For Employer &amp; Business Partners:</span>

            <span><a href="#">
                <i class="fas fa-phone-square-alt"></i> +91 8448-191-806</a></span>

            <span>| For Job Seekers: 
                <a href="#"><i class="fas fa-phone-square-alt"></i> +91 8800-788-596</a></span>
            </div>

            <div class="col-lg-6 col-12 d-flex justify-content-end">
               <div class="upload-resume">
                <a href="#" target="_blank"><i class="fas fa-upload"></i> Upload Your CV</a>
               </div>

               <div class="social-icon">
                <ul>
                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
               </div>

         
            </div>
        </div>
    </div>
</div>
